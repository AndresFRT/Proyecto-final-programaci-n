package Controllers;

import Models.Accion;
import Models.Cliente;
import Models.Modelo;
import Views.Vista;

import java.util.LinkedList;
import java.util.List;

/**
 * Controlador MVC del sistema TechClassUC.
 * Conecta los eventos de la Vista con la lógica del Modelo
 * y actualiza los componentes gráficos con los resultados.
 */
public class Controlador {

    private Modelo modelo;
    private Vista vista;

    // Contador de IDs auto-incrementado para nuevos clientes
    private int contadorID = 1;

    public Controlador(Modelo modelo, Vista vista) {
        this.modelo = modelo;
        this.vista = vista;
        iniciar();
        configurarListeners();
    }

    /** Hace visible la ventana principal centrada en pantalla. */
    private void iniciar() {
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
        actualizarEstadisticas();
    }

    // =========================================================
    // LISTENERS
    // =========================================================

    private void configurarListeners() {

        // --- Agregar cliente ---
        vista.getBTNagregar().addActionListener(e -> accionAgregar());

        // --- Eliminar cliente de la cola ---
        vista.getBTNeliminar().addActionListener(e -> accionEliminar());

        // --- Atender siguiente cliente ---
        vista.getBTNatender().addActionListener(e -> accionAtender());

        // --- Cancelar / deshacer última acción ---
        vista.getBTNcancelar().addActionListener(e -> accionCancelar());

        // --- Restaurar (undo explícito desde botón) ---
        vista.getBTNrestaurar().addActionListener(e -> accionRestaurar());

        // --- Buscar en historial ---
        vista.getBTNbuscar().addActionListener(e -> accionBuscar());

        // --- Reiniciar sistema ---
        vista.getBTNreiniciar().addActionListener(e -> accionReiniciar());

        // --- Salir ---
        vista.getBTNsalir().addActionListener(e -> System.exit(0));
    }

    // =========================================================
    // ACCIONES
    // =========================================================

    /** Lee los campos del formulario, valida y agrega el cliente a la cola. */
    private void accionAgregar() {
        String nombre    = vista.getTFnom().getText().trim();
        String tipoSoli  = (String) vista.getCBsoli().getSelectedItem();
        String prioridad = (String) vista.getCBprioridad().getSelectedItem();

        if (nombre.isEmpty()) {
            mostrarUltimaAccion("Ingrese un nombre para el cliente.");
            return;
        }

        Cliente nuevo = new Cliente(contadorID++, nombre, tipoSoli, prioridad);
        modelo.agregarCliente(nuevo);

        vista.getTFnom().setText("");
        vista.getTFid().setText("");
        actualizarColaEspera();
        actualizarEstadisticas();
        mostrarUltimaAccion("Cliente agregado: " + nuevo);
    }

    /** Elimina un cliente de la cola usando el ID o el nombre ingresado. */
    private void accionEliminar() {
        String criterio  = (String) vista.getCBeliminar().getSelectedItem();
        String valorTexto = vista.getTFeliminar().getText().trim();

        if (valorTexto.isEmpty()) {
            mostrarUltimaAccion("Ingrese el valor para eliminar.");
            return;
        }

        boolean eliminado = false;

        if ("ID".equalsIgnoreCase(criterio)) {
            try {
                int id = Integer.parseInt(valorTexto);
                eliminado = modelo.eliminarClientePorID(id);
            } catch (NumberFormatException ex) {
                mostrarUltimaAccion("El ID debe ser un número entero.");
                return;
            }
        }

        vista.getTFeliminar().setText("");

        if (eliminado) {
            actualizarColaEspera();
            actualizarEstadisticas();
            mostrarUltimaAccion("Cliente eliminado de la cola.");
        } else {
            mostrarUltimaAccion("No se encontró el cliente en la cola.");
        }
    }

    /** Atiende al primer cliente de la cola y lo pasa al historial. */
    private void accionAtender() {
        Cliente atendido = modelo.atenderCliente();
        if (atendido == null) {
            mostrarUltimaAccion("No hay clientes en espera.");
            return;
        }
        actualizarColaEspera();
        actualizarHistorial();
        actualizarEstadisticas();
        mostrarUltimaAccion("Atendido: " + atendido);
    }

    /** Deshace la última acción (cancelar). */
    private void accionCancelar() {
        Accion revertida = modelo.deshacerUltimaAccion();
        if (revertida == null) {
            mostrarUltimaAccion("No hay acciones que deshacer.");
            return;
        }
        actualizarColaEspera();
        actualizarHistorial();
        actualizarEstadisticas();
        mostrarUltimaAccion("Acción deshecha: " + revertida.getTipo().toUpperCase()
                + " | " + revertida.getCliente().getNombre());
    }

    /** Igual que cancelar — mismo comportamiento, botón diferente en la vista. */
    private void accionRestaurar() {
        accionCancelar();
    }

    /** Busca clientes en el historial por tipo de solicitud o por ID. */
    private void accionBuscar() {
        String tipoSoli = (String) vista.getCBsoliBuscar().getSelectedItem();
        String idTexto  = vista.getTFidBuscar().getText().trim();

        StringBuilder sb = new StringBuilder();

        if (!idTexto.isEmpty()) {
            try {
                int id = Integer.parseInt(idTexto);
                Cliente encontrado = modelo.buscarPorID(id);
                if (encontrado != null) {
                    sb.append(encontrado).append("\n");
                } else {
                    sb.append("No se encontró cliente con ID ").append(id);
                }
            } catch (NumberFormatException ex) {
                sb.append("El ID debe ser un número entero.");
            }
        } else if (tipoSoli != null && !tipoSoli.isEmpty()) {
            LinkedList<Cliente> resultados = modelo.buscarPorTipoSolicitud(tipoSoli);
            if (resultados.isEmpty()) {
                sb.append("No hay clientes atendidos con solicitud: ").append(tipoSoli);
            } else {
                for (Cliente c : resultados) {
                    sb.append(c).append("\n");
                }
            }
        } else {
            sb.append("Ingrese un ID o seleccione un tipo de solicitud.");
        }

        vista.getTAatendidos().setText(sb.toString());
    }

    /** Reinicia todas las estructuras y limpia la interfaz. */
    private void accionReiniciar() {
        modelo = new Modelo();
        contadorID = 1;
        vista.getTAespera().setText("");
        vista.getTAatendidos().setText("");
        vista.getTAacciones().setText("");
        vista.getTAultima().setText("");
        actualizarEstadisticas();
        mostrarUltimaAccion("Sistema reiniciado.");
    }

    // =========================================================
    // ACTUALIZACIÓN DE LA VISTA
    // =========================================================

    /** Refresca el área de texto que muestra la cola de espera. */
    private void actualizarColaEspera() {
        StringBuilder sb = new StringBuilder();
        int pos = 1;
        for (Cliente c : modelo.getColaEspera()) {
            sb.append(pos++).append(". ").append(c).append("\n");
        }
        vista.getTAespera().setText(sb.toString());
    }

    /** Refresca el área de texto del historial de atendidos. */
    private void actualizarHistorial() {
        StringBuilder sb = new StringBuilder();
        int pos = 1;
        for (Cliente c : modelo.getHistorialAtendidos()) {
            sb.append(pos++).append(". ").append(c).append("\n");
        }
        vista.getTAatendidos().setText(sb.toString());
    }

    /** Actualiza los contadores y estadísticas en los JTextField. */
    private void actualizarEstadisticas() {
        vista.getTFespera().setText(String.valueOf(modelo.getTotalEnEspera()));
        vista.getTFatendidos().setText(String.valueOf(modelo.getTotalAtendidos()));
        vista.getTFagregados().setText(String.valueOf(modelo.getContadorAgregados()));
        vista.getTFeliminados().setText(String.valueOf(modelo.getContadorEliminados()));
        vista.getTFaccionesTotales().setText(String.valueOf(modelo.getTotalAcciones()));

        double promedio = modelo.getPromedioTiempoAtencion();
        vista.getTFpromedio().setText(String.format("%.0f s", promedio));

        // Actualizar traza de acciones
        List<Accion> traza = modelo.getTraza();
        StringBuilder sb = new StringBuilder();
        for (Accion a : traza) {
            sb.append(a).append("\n");
        }
        vista.getTAacciones().setText(sb.toString());
    }

    /** Muestra un mensaje en el área de última acción. */
    private void mostrarUltimaAccion(String mensaje) {
        vista.getTAultima().setText(mensaje);
    }
}
