package Models;
import java.time.LocalDateTime;
public class Cliente {
    
    private int ID;
    private String nombre,tipoSoli,prioridad;
    private int tiempoAtencion;
    private LocalDateTime horaLlegada;
    
    public Cliente(int ID,String nombre,String tipoSoli,String prioridad){
        
        this.ID=ID;this.nombre=nombre;this.tipoSoli=tipoSoli;
        this.prioridad=prioridad;
        this.tiempoAtencion=5;
        this.horaLlegada=LocalDateTime.now();
        
    }
    
    public int getID(){
        return ID;
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public String getTipoSoli(){
        return tipoSoli;
    }
    
    public String getPrioridad(){
        return prioridad;
    }
    
    public int getTiempoAtencion(){
        return tiempoAtencion;
    }
    
    public LocalDateTime getHoraLlegada(){
        return horaLlegada;
    }
    
    public String toString(){
        return "["+ID+"] "+nombre+" | "+tipoSoli+" | "+prioridad+" | "+horaLlegada.toLocalTime();
    }
    
}