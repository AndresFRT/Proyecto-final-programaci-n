package Models;
import java.util.*;
public class Modelo{

    private ArrayDeque<Cliente> colaEspera=new ArrayDeque<>();
    private LinkedList<Cliente> listaAtendidos=new LinkedList<>();
    private Stack<Accion> pilaAcciones=new Stack<>();

    private int totalTiempoAtencion,contadorAgregados,contadorEliminados,contadorCancelados;

    public void agregarCliente(Cliente c){

    if("urgente".equalsIgnoreCase(c.getPrioridad())){
        
        ArrayDeque<Cliente> n=new ArrayDeque<>(); boolean ins=false;
        
        for(Cliente x: colaEspera){
            if(!ins && !"urgente".equalsIgnoreCase(x.getPrioridad())){
                n.add(c); ins=true;
            }
            n.add(x);
        }
        
        if(!ins)n.add(c);
        colaEspera=n;
        
    } else colaEspera.addLast(c);

    pilaAcciones.push(new Accion(Accion.AGREGAR,c));
    contadorAgregados++;

    }
    
    public boolean eliminarClientePorID(int id){
        
        int pos=0;
        Cliente elim=null;
        ArrayDeque<Cliente> n=new ArrayDeque<>();
        for(Cliente c: colaEspera){
            if(elim==null&&c.getID()==id){
                elim=c;
            }
            else {
                n.add(c);
            } pos++;
        }
        colaEspera=n;
        if(elim!=null){
            pilaAcciones.push(new Accion(Accion.ELIMINAR,elim,pos));
            contadorEliminados++;
            return true;
        }
        return false;
    }
    
    public Cliente atenderCliente(){
        if(colaEspera.isEmpty())return null;
        Cliente c=colaEspera.pollFirst();
        listaAtendidos.add(c);
        pilaAcciones.push(new Accion(Accion.ATENDER,c));
        totalTiempoAtencion+=5; return c;
    }
    
    public Accion deshacerUltimaAccion(){
        if(pilaAcciones.empty()) return null;
        Accion a=pilaAcciones.pop();
        Cliente c=a.getCliente();
        if(a.getTipo().equals("agregar")){
            colaEspera.removeIf(x->x.getID()==c.getID());
        } else if(a.getTipo().equals("eliminar")){
            ArrayList<Cliente> l=new ArrayList<>(colaEspera);
            int p=Math.min(a.getPosicion(),l.size());
            l.add(p,c); colaEspera=new ArrayDeque<>(l);
        } else if(a.getTipo().equals("atender")){
            listaAtendidos.remove(c);
            colaEspera.addFirst(c);
        }
        return a;
    }
    
    public LinkedList<Cliente> getHistorialAtendidos(){
        return listaAtendidos;
    }
    
    public LinkedList<Cliente> buscarPorTipoSolicitud(String t){
        LinkedList<Cliente> r=new LinkedList<>();
        for(Cliente c:listaAtendidos)
            if(c.getTipoSoli().equalsIgnoreCase(t)) r.add(c);
        return r;
    }
    
    public Cliente buscarPorID(int id){
        for(Cliente c:listaAtendidos) if(c.getID()==id)return c;
        for(Cliente c:colaEspera)
            if(c.getID()==id)return c;
        return null;
    }
    
    public List<Accion> getTraza(){
        List<Accion> t=new ArrayList<>(pilaAcciones);
        Collections.reverse(t); return t;
    }
    
    public int getTotalEnEspera(){
        return colaEspera.size();
    }
    
    public int getTotalAtendidos(){
        return listaAtendidos.size();
    }
    
    public int getTotalAcciones(){
        return pilaAcciones.size();
    }
    
    public int getContadorAgregados(){
        return contadorAgregados;
    }
    
    public int getContadorEliminados(){
        return contadorEliminados;
    }
    
    public int getContadorCancelados(){
        return contadorCancelados;
    }
    
    public double getPromedioTiempoAtencion(){
        return listaAtendidos.isEmpty()?0:(double)totalTiempoAtencion/listaAtendidos.size();
    }
    
    public ArrayDeque<Cliente> getColaEspera(){
        return colaEspera;
    }
    
}