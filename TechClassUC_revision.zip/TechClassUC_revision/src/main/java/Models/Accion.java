package Models;
import java.time.*;import java.time.format.*;
public class Accion{
    
    public static final String AGREGAR="agregar",ELIMINAR="eliminar",ATENDER="atender";
    
    private String tipo; private Cliente cliente;
    private LocalDateTime fechaHora;
    private int posicion;
    
    public Accion(String t, Cliente c){
        this(t,c,-1);
    }
    
    public Accion(String t,Cliente c,int p){
        tipo=t;cliente=c;posicion=p;fechaHora=LocalDateTime.now();
    }
    
    public String getTipo(){
        return tipo;
    }
    
    public Cliente getCliente(){
        return cliente;
    }
    
    public int getPosicion(){
        return posicion;
    }
    
    public String toString(){
        return tipo.toUpperCase()+" | "+cliente+" | "+fechaHora.format(DateTimeFormatter.ofPattern("dd/MM HH:mm:ss"));
    }
}