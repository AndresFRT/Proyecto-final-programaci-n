package App;

import Controllers.Controlador;
import Models.Modelo;
import Views.Vista;

/**
 * Punto de entrada del sistema TechClassUC.
 * Crea las tres capas MVC y lanza la aplicación.
 */
public class Main {

    public static void main(String[] args) {
        Modelo modelo = new Modelo();
        Vista vista = new Vista();
        Controlador controlador = new Controlador(modelo, vista);
    }
}
